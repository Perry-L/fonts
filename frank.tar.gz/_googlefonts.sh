#!/bin/sh

for d in "$@" ; do
  cd "$d"
  echo "Going to convert $d"
  
  cp /home/frank/ILI9341-FONTS/ttf_to_ili9341.pl .
  cp /home/frank/ILI9341-FONTS/bdf_to_ili9341 .
  
  for i in *.ttf;
  do 
	 name=$(echo $i| cut -f 1 -d '.');
	./ttf_to_ili9341.pl "$name";
  done
  
  rm bdf_to_ili9341
  rm ttf_to_ili9341.pl
  
done
