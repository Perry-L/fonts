#!/bin/sh

find /home/frank/ILI9341-FONTS -iname '*.ttf' -printf '%h\000' | sort -z -u | 
  xargs -0 -r /home/frank/ILI9341-FONTS/_googlefonts.sh

